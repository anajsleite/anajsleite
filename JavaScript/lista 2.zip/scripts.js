function exe1(){
    //exercícios  1 e 2

    let n1 = Number(document.getElementById("n1").value)
    let n2 = Number(document.getElementById("n2").value)
    let n3 = Number(document.getElementById("n3").value)
    let n4 = Number(document.getElementById("n4").value)
   

    let media = (n1 + n2 + n3 + n4) / 4

    if (media >= 0 && media < 3){
        alert("Reprovado com média: " + media.toFixed(2))
    }
    else if (media >= 3 && media < 7){
        alert("Em exame com média: " + media.toFixed(2))
    }
    else if (media >= 7){
        alert("Aprovado com média: " + media.toFixed(2))
    }
    else{
        alert("Impossível calcular a situação do aluno!")
    }

    
}
function exe2(){
    //exercício 3

    let n1 = Number(document.getElementById("n1").value)
    let n2 = Number(document.getElementById("n2").value)
    
    if (n1 < n2){
        alert("O menor número é: " + n1)
    }
    else if (n1 > n2){
        alert("O menor número é: " + n2)
    }
    else{
        alert("Os números informados são Iguais!")
    }
    
}
function exe3(){
    //exercício 4

    let n1 = Number(document.getElementById("n1").value)
    let n2 = Number(document.getElementById("n2").value)
    let n3 = Number(document.getElementById("n3").value)
    
    if (n1 > n2 && n1 > n3){
        alert("O maior número é: " + n1)
    }
    else if (n2 > n1 && n2 > n3){
        alert("O maior número é: " + n2)
    }
    else if (n3 > n2 && n3 > n1){
        alert("O maior número é: " + n3)
    }
    else{
        alert("Não existe número maior!")
    }
    
}
function exe4(){
    //exercício 5

    let num1 = Number(document.getElementById("num1").value)
    let num2 = Number(document.getElementById("num2").value)
    let opcao = Number(document.getElementById("opcao").value)
    
    switch (opcao) {
        case 1:
            let media = (num1 + num2) / 2
            alert("A média entre os números digitados é: " + media)
            break;
        case 2:
            if (num1 > num2){
                let diferenca = num1 - num2
                alert("A diferença entre o maior número e o menor é: " + diferenca)
                break;
            }
            else if (num2 > num1){
                let diferenca = num2 - num1
                alert("A diferença entre o maior número e o menor é: " + diferenca)
                break;
            } 
            // para substituir td pode se usar: diferenca = (n1 > n2) ? n1 - n2 : n2 - n1 (operador ternário)
            //nesse caso ficaria:
            //diferenca = (n1 > n2) ? n1 - n2 : n2 - n1
            //alert("A diferença entre os números digitados é: " ${diferença})
            else{
                let diferenca = 0
                alert("A diferença entre o maior número e o menor é: " + diferenca)
                break;
            }
        case 3:
            multiplicacao = num1 * num2
            alert("O produto entre os dois números é: " + multiplicacao)
            break;
        case 4:
            if (num2 != 0){
                divisao = num1 / num2
                alert("A divisão é: " + divisao)
            }
            else{
                alert("O denominador deve ser diferente de 0!")
            }

            break;
        default:
            alert("Opção Inválida!")
            break;
    }

}
function exe5(){
    //exercício 6

    let num1 = Number(document.getElementById("num1").value)
    let num2 = Number(document.getElementById("num2").value)
    let opcao = document.getElementById("opcao").value
    
    switch (opcao) {
        case "A":
            potencia = Math.pow(num1, num2);
            alert("O primeiro número elevado ao segundo é: " + potencia)
            break;
        case "B":
            raiz1 = Math.sqrt(num1)
            raiz2 = Math.sqrt(num2)
            alert(`As Raizes Quadradas são:  ${raiz1} e ${raiz2}`)
            break;
        case "C":
            cubica = Math.cbrt(num1)
            alert("A Raiz cúbica do primeiro número é: " + cubica)
            cubica = Math.cbrt(num2)
            alert("A Raiz cúbica do segundo número é: " + cubica)
            break;
        default:
            alert("Opção Inválida!")
            break;
    }

}
function exe6(){
    //Exercício 7
    let salario = Number(document.getElementById("salario").value)
        
    if (salario >= 500){
        aumento = salario * 0.3
        novo_salario = salario + aumento
        alert("O valor do salário reajustado é: " + novo_salario)
    }    
    else{
        alert("O funcionário não tem direito ao aumento!")
    }

}
function exe7(){
    //exercício 8
    
    let salario = Number(document.getElementById("salario").value)
    
    if (salario <= 300){
        aumento = salario * 0.35 
        novo_salario = salario + aumento
        alert("O salário reajustado é: " + novo_salario.toFixed(2))
    }
    else {
        aumento = salario * 0.15
        novo_salario = salario + aumento
        alert("O salário reajustado é: " + novo_salario.toFixed(2))
    }
    
}
function exe8(){
    //exercício 9
    let saldo = Number(document.getElementById("saldo").value)
    
    if (saldo <= 200){
        let credito = saldo * 0.1
        alert("O valor do crédito concedido é: " + credito.toFixed(2))
    }
    else if (saldo > 200 & saldo <= 300){
        let credito = saldo * 0.2
        alert("O valor do crédito concedido é: " + credito.toFixed(2))
    }
    else if (saldo > 300 & saldo <= 400){
        let credito = saldo * 0.25
        alert("O valor do crédito concedido é: " + credito.toFixed(2))
    }    
    else{
        let credito = saldo * 0.30
        alert("O valor do crédito concedido é: " + credito.toFixed(2))
    }
}
function exe9(){
    //exercício 10

    let custo = Number(document.getElementById("custo").value)
    
    if (custo <= 12000){
        distribuidor = custo * 0.05
        preco = custo + distribuidor
        alert("O preço ao consumidor é: " +preco)
    }
    else if (custo > 12000 && custo < 25000){
        distribuidor = custo * 0.1
        imposto = custo * 0.15
        preco = custo + distribuidor + imposto
        alert("O preço ao consumidor é: " +preco)
    }
    else{
        distribuidor = custo * 0.15
        imposto = custo * 0.20
        preco = custo + distribuidor + imposto
        alert("O preço ao consumidor é: " +preco)
    }
}
function exe10(){ 
    //exercício 22

    let idade = Number(document.getElementById("idade").value)
    let peso = Number(document.getElementById("peso").value)
     let risco
    if (idade < 20){
        if (peso <= 60){
            risco = 9
        }
        else if (peso >= 60 && peso <= 90){
            risco = 8
        }
        else if (peso > 90){
            risco = 7
        }
        else{
            alert("Erro!")
        }
    }
    if (idade >= 20 && idade <=50){
        if (peso <= 60){
            risco = 6
        }
        else if (peso >= 60 && peso <= 90){
            risco = 5
        }
        else if (peso > 90){
            risco = 4
        }
        else{
            alert("Erro!")
        }
    }
    if (idade > 50){
        if (peso <= 60){
            risco = 3
        }
        else if (peso >= 60 && peso <= 90){
            risco = 2
        }
        else if (peso > 90){
            risco = 1
        }
        else{
            alert("Erro!")
        }
    }
    alert(`O risco é: ${risco}`)
}
function exe11(){ 
    //exercício 23

    let codigo = Number(document.getElementById("codigo").value)
    let quantidade = Number(document.getElementById("quantidade").value)
    let preco_uni
    let preco_nota
    let desconto
    let preco_final

    if (codigo >= 1 && codigo <=10){
        preco_uni = 10
        preco_nota = preco_uni * quantidade
        if (preco_nota < 250){
            desconto = preco_nota * 0.05
        }
        else if (preco_nota >= 250 && preco_nota <= 500){
            desconto = preco_nota * 0.1
        }
        else if (preco_nota > 500){
            desconto = preco_nota * 0.15
        }
        
    else if (codigo >= 11 && codigo <=20){
            preco_uni = 15
            preco_nota = preco_uni * quantidade
            if (preco_nota < 250){
                desconto = preco_nota * 0.05
            }
            else if (preco_nota >= 250 && preco_nota <= 500){
                desconto = preco_nota * 0.1
            }
            else if (preco_nota > 500){
                desconto = preco_nota * 0.15
            }
    }
    else if (codigo >= 21 && codigo <=30){
        preco_uni = 20
        preco_nota = preco_uni * quantidade
        if (preco_nota < 250){
            desconto = preco_nota * 0.05
        }
        else if (preco_nota >= 250 && preco_nota <= 500){
            desconto = preco_nota * 0.1
        }
        else if (preco_nota > 500){
            desconto = preco_nota * 0.15
        }
    }
    else if (codigo >= 31 && codigo <=40){
        preco_uni = 30
        preco_nota = preco_uni * quantidade
        if (preco_nota < 250){
            desconto = preco_nota * 0.05
        }
        else if (preco_nota >= 250 && preco_nota <= 500){
            desconto = preco_nota * 0.1
        }
        else if (preco_nota > 500){
            desconto = preco_nota * 0.15
        }
    }
    else{
        alert("Erro!")
    }
        preco_final = preco_nota - desconto
        alert(`O preço unitário é: R$ ${preco_uni.toFixed(2)} \n o preço total da Nota é: R$ ${preco_nota.toFixed(2)} \n o valor do desconto é: R$ ${desconto.toFixed(2)} \n o valor final é: R$ ${preco_final.toFixed(2)}`)

    }

}